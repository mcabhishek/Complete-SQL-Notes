USE sql_notes;
-- Database-Design-Practice.sql : 26 Q (Beg 1-9, Inter 10-17, Adv 18-26)
-- Q1 Beg PK students (Concept: keys)
SHOW KEYS FROM students WHERE Key_name='PRIMARY'; -- student_id
-- Q2 Beg FK students (Concept: FK)
SELECT CONSTRAINT_NAME,REFERENCED_TABLE_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA='sql_notes' AND TABLE_NAME='students' AND REFERENCED_TABLE_NAME IS NOT NULL; -- fk_stu_dept->departments
-- Q3 Beg UQ email test rollback (Concept: UNIQUE)
START TRANSACTION; -- INSERT INTO students (name,email,dept_id,enrollment_year) VALUES ('Dup','abhishek@college.edu',1,2024); -- 1062
ROLLBACK;
-- Q4 Beg NOT NULL/DEFAULT (Concept)
DESCRIBE students; -- name NO, enrollment_year DEFAULT YEAR(CURDATE())
-- Q5 Beg M-M query Abhishek courses (Concept: junction)
SELECT c.course_name FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id WHERE s.name='Abhishek'; -- DBMS, DS
-- Q6 Beg 1-M dept CS (Concept)
SELECT name FROM students WHERE dept_id=1; -- Abhishek, Jeevan
-- Q7 Beg 1-1 enr-mark (Concept)
SELECT e.enrollment_id,m.marks_obtained FROM enrollments e JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE e.enrollment_id=1; -- 88
-- Q8 Beg orphan check (Concept: RI)
SELECT COUNT(*) AS orphans FROM enrollments e LEFT JOIN students s ON e.student_id=s.student_id WHERE s.student_id IS NULL; -- 0
-- Q9 Beg insert order (Concept) -- Answer: departments, students/courses, enrollments, marks/attendance.
-- Q10 Inter choose email constraint (Concept: UNIQUE+NOT NULL)
-- Answer: UNIQUE prevents dupes; keep nullable? ours nullable but filled. SHOW CREATE TABLE students;
-- Q11 Inter add CHECK (Concept: ALTER)
-- ALTER TABLE courses ADD CONSTRAINT chk_credits2 CHECK (credits BETWEEN 1 AND 6); -- already exists chk_credits; DROP if test: ALTER TABLE courses DROP CHECK chk_credits2;
-- Q12 Inter composite key (Concept)
SHOW KEYS FROM enrollments WHERE Key_name='uq_enroll'; -- student_id,course_id,academic_year
-- Q13 Inter fix 1NF phones (Concept: atomic)
-- CREATE TABLE student_phones (student_id INT, phone VARCHAR(15), PRIMARY KEY(student_id,phone), FOREIGN KEY(student_id) REFERENCES students(student_id));
-- Q14 Inter 2NF split demo (Concept: partial)
-- Bad enroll_big(student_id,course_id,course_name...) -> good courses+enrollments (as in 2NF.md).
-- Q15 Inter 3NF HOD update once (Concept: transitive)
SELECT d.hod_name FROM students s JOIN departments d ON s.dept_id=d.dept_id WHERE s.name='Abhishek'; -- Dr. Ramesh Kumar; START TRANSACTION; UPDATE departments SET hod_name='Dr. X' WHERE dept_id=1; ROLLBACK;
-- Q16 Inter FK actions list (Concept)
SELECT TABLE_NAME,CONSTRAINT_NAME,DELETE_RULE,UPDATE_RULE FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA='sql_notes'; -- RESTRICT depts, CASCADE enroll/marks/att
-- Q17 Inter junction design new clubs M-M (Concept)
-- CREATE TABLE clubs(club_id INT PRIMARY KEY AUTO_INCREMENT, club_name VARCHAR(100) UNIQUE); CREATE TABLE memberships(student_id INT, club_id INT, PRIMARY KEY(student_id,club_id), FOREIGN KEY(student_id) REFERENCES students(student_id), FOREIGN KEY(club_id) REFERENCES clubs(club_id));
-- Q18 Adv insertion anomaly (Concept)
-- Answer: flat (name,dept,hod) can't add Electronics dept without student; split departments allows INSERT dept alone.
-- Q19 Adv update anomaly count (Concept)
SELECT COUNT(*) FROM students WHERE dept_id=1; -- 2 rows would repeat HOD flat; split 1 row update.
-- Q20 Adv deletion anomaly (Concept)
-- Answer: delete last CS student flat loses dept; split keeps departments row 1.
-- Q21 Adv BCNF check (Concept)
-- Answer: dept_id->hod with dept_id key ok; hod unique -> BCNF holds.
-- Q22 Adv lossless test (Concept)
SELECT s.name,d.dept_name FROM students s JOIN departments d ON s.dept_id=d.dept_id; -- 5 rows back exactly, no fan-out.
-- Q23 Adv natural vs surrogate (Concept) -- Answer: email natural unstable, student_id surrogate stable PK.
-- Q24 Adv SET NULL vs RESTRICT (Concept) -- Answer: SET NULL needs nullable FK; ours NOT NULL so RESTRICT/CASCADE only.
-- Q25 Adv over-normalize warning (Concept) -- Answer: splitting every attr slows joins; keep meaningful tables.
-- Q26 Adv ER to DDL (Concept) -- Answer: Mermaid in ER-Model.md maps 1-1 to CREATE in Create-Tables.sql order.
