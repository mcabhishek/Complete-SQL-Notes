USE sql_notes;
-- Data-Modification-Practice.sql : 26 Q (Beg 1-9, Inter 10-18, Adv 19-26). All destructive wrapped in txn+rollback.
-- Q1 Beg: new course (Concept: INSERT valid FK)
INSERT INTO courses (course_name,credits,dept_id) VALUES ('Test Course Q1',3,1);
SELECT * FROM courses WHERE course_name='Test Course Q1'; -- 1 row
DELETE FROM courses WHERE course_name='Test Course Q1'; -- cleanup
-- Q2 Beg: valid enrollment Likhith+DS 2024-25 (Concept: UNIQUE/FK)
START TRANSACTION;
INSERT INTO enrollments (student_id,course_id,semester,academic_year) VALUES (3,2,4,'2024-25');
SELECT * FROM enrollments WHERE student_id=3 AND course_id=2 AND academic_year='2024-25'; -- 1 row
ROLLBACK;
-- Q3 Beg: update Likhith age (Concept: PK WHERE + preview)
SELECT * FROM students WHERE student_id=3;
START TRANSACTION; UPDATE students SET age=21 WHERE student_id=3; SELECT age FROM students WHERE student_id=3; -- 21
ROLLBACK; -- restores 20
-- Q4 Beg: update marks enr 5 to 60 (Concept: single-row UPDATE)
START TRANSACTION; UPDATE marks SET marks_obtained=60.00, grade='C' WHERE enrollment_id=5; SELECT * FROM marks WHERE enrollment_id=5; ROLLBACK;
-- Q5 Beg: delete test enrollment (Concept: safe DELETE)
START TRANSACTION;
INSERT INTO enrollments (enrollment_id,student_id,course_id,semester,academic_year) VALUES (900,3,4,4,'2024-25');
DELETE FROM enrollments WHERE enrollment_id=900; SELECT * FROM enrollments WHERE enrollment_id=900; -- empty
ROLLBACK;
-- Q6 Beg: INSERT..SELECT backup toppers (Concept: copy)
DROP TABLE IF EXISTS q6_top; CREATE TABLE q6_top AS SELECT s.name,m.marks_obtained FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE m.marks_obtained>=85; SELECT * FROM q6_top; -- 3 rows 95,92,88
DROP TABLE q6_top;
-- Q7 Beg: ACID one-liner (Concept: theory) -- Answer: Atomicity all-or-nothing, Consistency valid state, Isolation hidden uncommitted, Durability survives crash.
-- Q8 Beg: PK/FK of students (Concept: keys) -- Answer: PK student_id, FK dept_id->departments, UQ email.
-- Q9 Beg: preview before update (Concept: safety) -- Pattern: SELECT same WHERE, then txn.
-- Q10 Inter: bonus +2 Jeevitha DBMS capped (Concept: UPDATE subquery)
START TRANSACTION; UPDATE marks SET marks_obtained=LEAST(marks_obtained+2,100) WHERE enrollment_id IN (SELECT enrollment_id FROM enrollments WHERE student_id=4 AND course_id=1); SELECT * FROM marks WHERE enrollment_id=7; ROLLBACK;
-- Q11 Inter: FK error demo (Concept: 1452)
-- INSERT INTO enrollments (student_id,course_id,semester,academic_year) VALUES (999,1,3,'2023-24'); -- ERROR 1452 parent missing
-- Q12 Inter: parent delete blocked (Concept: 1451 RESTRICT)
-- DELETE FROM departments WHERE dept_id=1; -- ERROR 1451 children exist
-- Q13 Inter: savepoint keep first (Concept: SAVEPOINT)
START TRANSACTION; INSERT INTO departments (dept_name,hod_name) VALUES ('Q13A','H'); SAVEPOINT s1; INSERT INTO departments (dept_name,hod_name) VALUES ('Q13B','H'); ROLLBACK TO s1; SELECT * FROM departments WHERE dept_name LIKE 'Q13%'; -- only Q13A
ROLLBACK; -- cleanup Q13A
-- Q14 Inter: rollback demo enroll chain (Concept: atomicity)
START TRANSACTION; INSERT INTO enrollments (enrollment_id,student_id,course_id,semester,academic_year) VALUES (901,3,4,4,'2024-25'); INSERT INTO marks (enrollment_id,marks_obtained,max_marks,grade) VALUES (901,70,100,'B'); ROLLBACK; SELECT * FROM enrollments WHERE enrollment_id=901; -- empty
-- Q15 Inter: UPDATE JOIN CS Abhishek year (Concept: MySQL JOIN update)
START TRANSACTION; UPDATE students s JOIN departments d ON s.dept_id=d.dept_id SET s.enrollment_year=2023 WHERE s.student_id=1 AND d.dept_name='Computer Science'; SELECT * FROM students WHERE student_id=1; ROLLBACK;
-- Q16 Inter: DELETE with subquery marks 100 (Concept: subquery delete, 0 rows)
START TRANSACTION; DELETE FROM marks WHERE enrollment_id IN (SELECT enrollment_id FROM enrollments WHERE enrollment_id=100); SELECT ROW_COUNT(); -- 0
ROLLBACK;
-- Q17 Inter: UNION backup honor avg>=80 (Concept: INSERT..SELECT aggregate)
DROP TABLE IF EXISTS q17_h; CREATE TABLE q17_h AS SELECT s.name,AVG(m.marks_obtained) a FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id GROUP BY s.name HAVING AVG(m.marks_obtained)>=80; SELECT * FROM q17_h; -- 4 rows (Abhishek,Jeevan,Jeevitha,Manjunath)
DROP TABLE q17_h;
-- Q18 Inter: safe-updates block (Concept: 1175)
SET SQL_SAFE_UPDATES=1; -- UPDATE students SET age=21; -- blocked 1175
SET SQL_SAFE_UPDATES=0;
-- Q19 Adv: full chain commit then cleanup (Concept: COMMIT durability)
START TRANSACTION; INSERT INTO departments (dept_name,hod_name) VALUES ('Q19T','H'); COMMIT; SELECT * FROM departments WHERE dept_name='Q19T'; -- present
DELETE FROM departments WHERE dept_name='Q19T';
-- Q20 Adv: DDL implicit commit (Concept: non-rollbackable)
START TRANSACTION; INSERT INTO departments (dept_name,hod_name) VALUES ('Q20T','H'); CREATE TABLE q20_tmp (id INT); ROLLBACK; SELECT * FROM departments WHERE dept_name='Q20T'; -- still there!
DROP TABLE q20_tmp; DELETE FROM departments WHERE dept_name='Q20T';
-- Q21 Adv: anomaly demo delete dept loses students if cascaded (Concept: design) -- Answer: keep RESTRICT on dept to avoid loss.
-- Q22 Adv: choose constraint for email (Concept: UNIQUE+NOT NULL) -- Answer: UNIQUE prevents dupes.
-- Q23 Adv: M-M via enrollments (Concept: junction) -- Answer: enrollments(student_id,course_id) with uq triple.
-- Q24 Adv: 1NF fix phones csv (Concept: atomic) -- Answer: split to student_phones(student_id,phone).
-- Q25 Adv: 2NF/3NF/BCNF one-liners -- Answer: 2NF no partial on composite part; 3NF no transitive; BCNF every determinant superkey.
-- Q26 Adv: DELETE vs TRUNCATE vs DROP (Concept: scope) -- Answer: rows/filtered-undoable vs all-fast-commit vs table-gone.
