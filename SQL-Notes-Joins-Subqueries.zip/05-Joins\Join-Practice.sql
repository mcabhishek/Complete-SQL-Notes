USE sql_notes;
-- Join-Practice.sql : 20 Q (Beginner 1-7, Intermediate 8-14, Advanced 15-20)
-- Q1 Beginner: Students + dept names (INNER)
SELECT s.name, d.dept_name FROM students s JOIN departments d ON s.dept_id=d.dept_id;
-- Q2 Beginner: Student + courses (INNER 3-table)
SELECT s.name, c.course_name FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id ORDER BY s.name;
-- Q3 Beginner: All students + enrollments incl. unenrolled (LEFT)
SELECT s.name, e.course_id FROM students s LEFT JOIN enrollments e ON s.student_id=e.student_id;
-- Q4 Beginner: All courses + enrollments (RIGHT->LEFT form)
SELECT c.course_name, e.student_id FROM courses c LEFT JOIN enrollments e ON c.course_id=e.course_id ORDER BY c.course_id;
-- Q5 Beginner: DBMS students
SELECT s.name FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id WHERE c.course_name='Database Management';
-- Abhishek, Jeevan, Jeevitha
-- Q6 Beginner: Cross count
SELECT COUNT(*) AS combos FROM students CROSS JOIN departments; -- 15
-- Q7 Beginner: Classmates pairs (SELF)
SELECT a.name AS s1, b.name AS s2 FROM students a JOIN students b ON a.dept_id=b.dept_id AND a.student_id<b.student_id;
-- Abhishek-Jeevan, Likhith-Jeevitha
-- Q8 Intermediate: Students with no enrollment (anti-join)
SELECT s.name FROM students s LEFT JOIN enrollments e ON s.student_id=e.student_id WHERE e.enrollment_id IS NULL; -- empty
-- Q9 Intermediate: Courses with no enrollment
SELECT c.course_name FROM courses c LEFT JOIN enrollments e ON c.course_id=e.course_id WHERE e.enrollment_id IS NULL; -- empty
-- Q10 Intermediate: Enrollment count per course
SELECT c.course_name, COUNT(e.enrollment_id) AS n FROM courses c LEFT JOIN enrollments e ON c.course_id=e.course_id GROUP BY c.course_id,c.course_name;
-- DBMS 3, CN 2, others 1
-- Q11 Intermediate: Avg marks per student
SELECT s.name, ROUND(AVG(m.marks_obtained),2) AS avg_m FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id GROUP BY s.student_id,s.name;
-- Abhishek 81.50, Jeevan 80.00, Likhith 55.00, Jeevitha 86.50, Manjunath 82.00
-- Q12 Intermediate: Full report name-course-marks-grade
SELECT s.name,c.course_name,m.marks_obtained,m.grade FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id JOIN marks m ON m.enrollment_id=e.enrollment_id ORDER BY m.marks_obtained DESC;
-- Top Jeevitha-DBMS-95-A+
-- Q13 Intermediate: FULL OUTER simulation depts-students
SELECT d.dept_name,s.name FROM departments d LEFT JOIN students s ON d.dept_id=s.dept_id UNION SELECT d.dept_name,s.name FROM departments d RIGHT JOIN students s ON d.dept_id=s.dept_id;
-- Q14 Intermediate: Multiple conditions (sem 3 DBMS)
SELECT s.name,c.course_name FROM students s JOIN enrollments e ON s.student_id=e.student_id AND e.semester=3 JOIN courses c ON e.course_id=c.course_id WHERE c.course_name='Database Management';
-- Abhishek, Jeevitha
-- Q15 Advanced: Top scorer per course (join + group max)
SELECT c.course_name,s.name,m.marks_obtained FROM marks m JOIN enrollments e ON m.enrollment_id=e.enrollment_id JOIN students s ON e.student_id=s.student_id JOIN courses c ON e.course_id=c.course_id WHERE (e.course_id,m.marks_obtained) IN (SELECT e2.course_id,MAX(m2.marks_obtained) FROM enrollments e2 JOIN marks m2 ON m2.enrollment_id=e2.enrollment_id GROUP BY e2.course_id);
-- DBMS Jeevitha 95, DS Abhishek 75, CN Jeevitha 78, OS Jeevan 68, DE Manjunath 82
-- Q16 Advanced: Students enrolled in multiple courses
SELECT s.name,COUNT(*) AS c FROM students s JOIN enrollments e ON s.student_id=e.student_id GROUP BY s.student_id,s.name HAVING COUNT(*)>1;
-- Abhishek 2, Jeevan 2, Jeevitha 2
-- Q17 Advanced: Correct distinct count vs COUNT(*) demo
SELECT COUNT(*) AS joined_rows, COUNT(DISTINCT s.student_id) AS unique_students FROM students s JOIN enrollments e ON s.student_id=e.student_id;
-- 8 vs 5
-- Q18 Advanced: Missing combos (CROSS anti-join)
SELECT s.name,c.course_name FROM students s CROSS JOIN courses c LEFT JOIN enrollments e ON e.student_id=s.student_id AND e.course_id=c.course_id WHERE e.enrollment_id IS NULL;
-- 17 rows
-- Q19 Advanced: Dept with course count + student count
SELECT d.dept_name,COUNT(DISTINCT s.student_id) AS studs,COUNT(DISTINCT c.course_id) AS crs FROM departments d LEFT JOIN students s ON d.dept_id=s.dept_id LEFT JOIN courses c ON c.dept_id=d.dept_id GROUP BY d.dept_id,d.dept_name;
-- CS 2 studs 3 crs, IS 2/1, Elec 1/1
-- Q20 Advanced: High attendance + high marks
SELECT s.name,c.course_name,a.percentage,m.marks_obtained FROM students s JOIN attendance a ON a.student_id=s.student_id JOIN courses c ON c.course_id=a.course_id JOIN enrollments e ON e.student_id=s.student_id AND e.course_id=c.course_id JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE a.percentage>=90 AND m.marks_obtained>=85;
-- Abhishek-DBMS 90/88, Jeevitha-DBMS 95/95
