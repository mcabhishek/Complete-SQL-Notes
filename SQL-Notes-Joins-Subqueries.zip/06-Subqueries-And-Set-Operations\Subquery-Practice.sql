USE sql_notes;
-- Subquery-Practice.sql : 21 Q (Beg 1-7, Inter 8-14, Adv 15-21)
-- Q1 Beg scalar avg
SELECT AVG(marks_obtained) AS avg_m FROM marks; -- 79.125
-- Q2 Beg DBMS via IN
SELECT name FROM students WHERE student_id IN (SELECT student_id FROM enrollments WHERE course_id=1); -- Abhishek,Jeevan,Jeevitha
-- Q3 Beg above avg marks
SELECT s.name,m.marks_obtained FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE m.marks_obtained>(SELECT AVG(marks_obtained) FROM marks); -- 95,92,88,82
-- Q4 Beg second highest
SELECT DISTINCT marks_obtained FROM marks ORDER BY marks_obtained DESC LIMIT 1 OFFSET 1; -- 92
-- Q5 Beg multi-course (derived)
SELECT s.name FROM students s JOIN (SELECT student_id,COUNT(*) c FROM enrollments GROUP BY student_id) t ON t.student_id=s.student_id WHERE t.c>1; -- Abhishek,Jeevan,Jeevitha
-- Q6 Beg EXISTS enrolled
SELECT s.name FROM students s WHERE EXISTS (SELECT 1 FROM enrollments e WHERE e.student_id=s.student_id); -- all 5
-- Q7 Beg UNION CS+2023
SELECT name FROM students WHERE dept_id=1 UNION SELECT name FROM students WHERE enrollment_year=2023; -- 4 names
-- Q8 Inter highest per course (correlated)
SELECT c.course_name,s.name,m.marks_obtained FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE m.marks_obtained=(SELECT MAX(m2.marks_obtained) FROM enrollments e2 JOIN marks m2 ON m2.enrollment_id=e2.enrollment_id WHERE e2.course_id=e.course_id);
-- DBMS Jeevitha 95, DS Abhishek 75, CN Jeevitha 78, OS Jeevan 68, DE Manjunath 82
-- Q9 Inter above own avg
SELECT s.name,c.course_name,m.marks_obtained FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN courses c ON e.course_id=c.course_id JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE m.marks_obtained>(SELECT AVG(m2.marks_obtained) FROM enrollments e2 JOIN marks m2 ON m2.enrollment_id=e2.enrollment_id WHERE e2.student_id=s.student_id);
-- Abhishek-DBMS-88, Jeevan-DBMS-92, Jeevitha-DBMS-95
-- Q10 Inter NOT EXISTS unenrolled
SELECT s.name FROM students s WHERE NOT EXISTS (SELECT 1 FROM enrollments e WHERE e.student_id=s.student_id); -- empty
-- Q11 Inter ANY vs ALL on CN {55,78}
SELECT COUNT(*) FROM marks WHERE marks_obtained > ANY (SELECT m2.marks_obtained FROM marks m2 JOIN enrollments e2 ON m2.enrollment_id=e2.enrollment_id WHERE e2.course_id=3); -- 7 (>55)
SELECT COUNT(*) FROM marks WHERE marks_obtained > ALL (SELECT m2.marks_obtained FROM marks m2 JOIN enrollments e2 ON m2.enrollment_id=e2.enrollment_id WHERE e2.course_id=3); -- 4 (>78)
-- Q12 Inter UNION ALL count
SELECT COUNT(*) FROM (SELECT student_id FROM enrollments WHERE course_id=1 UNION ALL SELECT student_id FROM enrollments WHERE course_id=3) t; -- 5
-- Q13 Inter both courses (INTERSECT workaround)
SELECT s.name FROM students s WHERE s.student_id IN (SELECT student_id FROM enrollments WHERE course_id=1) AND s.student_id IN (SELECT student_id FROM enrollments WHERE course_id=3); -- Jeevitha
-- Q14 Inter DBMS not CN (EXCEPT workaround)
SELECT s.name FROM students s JOIN enrollments e ON s.student_id=e.student_id WHERE e.course_id=1 AND NOT EXISTS (SELECT 1 FROM enrollments x WHERE x.student_id=s.student_id AND x.course_id=3); -- Abhishek,Jeevan
-- Q15 Adv 2nd highest per course
SELECT e.course_id,MAX(m.marks_obtained) AS second_max FROM enrollments e JOIN marks m ON m.enrollment_id=e.enrollment_id WHERE m.marks_obtained<(SELECT MAX(m2.marks_obtained) FROM enrollments e2 JOIN marks m2 ON m2.enrollment_id=e2.enrollment_id WHERE e2.course_id=e.course_id) GROUP BY e.course_id;
-- DBMS 92, CN 55 (single others NULL->excluded, only DBMS+CN have 2 rows)
-- Q16 Adv above overall avg students (by avg)
SELECT s.name,AVG(m.marks_obtained) AS a FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id GROUP BY s.student_id,s.name HAVING AVG(m.marks_obtained)>(SELECT AVG(marks_obtained) FROM marks);
-- Abhishek 81.50, Jeevitha 86.50, Manjunath 82.00 (overall 79.125)
-- Q17 Adv nested 3-level: topper name
SELECT name FROM students WHERE student_id=(SELECT student_id FROM enrollments WHERE enrollment_id=(SELECT enrollment_id FROM marks ORDER BY marks_obtained DESC LIMIT 1)); -- Jeevitha (95,enr 7)
-- Q18 Adv compare JOIN vs IN (same result DBMS)
SELECT DISTINCT s.name FROM students s JOIN enrollments e ON s.student_id=e.student_id WHERE e.course_id=1; -- same as Q2
-- Q19 Adv NULL trap demo (returns empty - do NOT use)
SELECT name FROM students WHERE student_id NOT IN (1,2,NULL); -- empty, use NOT EXISTS instead
-- Q20 Adv FULL OUTER-like students-courses via UNION
SELECT s.name,c.course_name FROM students s LEFT JOIN enrollments e ON s.student_id=e.student_id LEFT JOIN courses c ON e.course_id=c.course_id UNION SELECT s.name,c.course_name FROM students s RIGHT JOIN enrollments e ON s.student_id=e.student_id RIGHT JOIN courses c ON e.course_id=c.course_id;
-- 8 matched rows
-- Q21 Adv rank via correlated count (how many scored higher)
SELECT s.name,m.marks_obtained,(SELECT COUNT(*)+1 FROM marks m2 WHERE m2.marks_obtained>m.marks_obtained) AS rank_no FROM students s JOIN enrollments e ON s.student_id=e.student_id JOIN marks m ON m.enrollment_id=e.enrollment_id ORDER BY rank_no;
-- 95 rank1 Jeevitha, 92 rank2 Jeevan, 88 rank3 Abhishek, 82 rank4 Manjunath, 78 rank5 Jeevitha, 75 rank6 Abhishek, 68 rank7 Jeevan, 55 rank8 Likhith
